import React from 'react';


const Idealista = () => {
  return(
    <h1>hola bondia catalunya</h1>
  )
}
export default Idealista;